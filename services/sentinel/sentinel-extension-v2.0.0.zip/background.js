// AZ-Lab Sentinel v2.0.0 — Background Service Worker
// Polls the Sentinel API with Fusion Mode, cross-device mirroring, and action parity

const DEFAULT_SETTINGS = {
  apiUrl: 'https://sentinel-api.az-lab.dev',
  apiKey: '',
  pollIntervalSeconds: 30,
  fusionMode: false,
  extensionId: generateClientId(),
  version: '2.0.0',
};

let settings = { ...DEFAULT_SETTINGS };
let consecutiveErrors = 0;
const MAX_BACKOFF = 8;

function generateClientId() {
  return `ext-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// ── Auto-migration from v1 settings ────────────────────────────────────────────

async function migrateSettingsIfNeeded() {
  const stored = await chrome.storage.sync.get();
  const hasVersion = 'version' in stored && stored.version === '2.0.0';

  if (!hasVersion && Object.keys(stored).length > 0) {
    console.log('[sentinel] migrating from v1 settings');
    const migrated = {
      ...DEFAULT_SETTINGS,
      apiUrl: stored.apiUrl || DEFAULT_SETTINGS.apiUrl,
      apiKey: stored.apiKey || '',
      pollIntervalSeconds: stored.pollIntervalSeconds || 30,
    };
    await chrome.storage.sync.set(migrated);
    console.log('[sentinel] migration complete');
    return migrated;
  }

  return null;
}

// ── Settings ───────────────────────────────────────────────────────────────────

async function loadSettings() {
  const stored = await chrome.storage.sync.get(DEFAULT_SETTINGS);
  settings = { ...DEFAULT_SETTINGS, ...stored };
}

async function saveSettings(updates) {
  settings = { ...settings, ...updates };
  await chrome.storage.sync.set(settings);
}

// ── Badge ──────────────────────────────────────────────────────────────────────

function updateBadge(count, error = false) {
  if (error) {
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#6B7280' });
    chrome.action.setBadgeTextColor({ color: '#FFFFFF' });
    return;
  }
  if (!count || count <= 0) {
    chrome.action.setBadgeText({ text: '' });
    return;
  }
  const label = count > 99 ? '99+' : String(count);
  chrome.action.setBadgeText({ text: label });
  chrome.action.setBadgeBackgroundColor({ color: '#EF4444' });
  chrome.action.setBadgeTextColor({ color: '#FFFFFF' });
}

// ── Polling ────────────────────────────────────────────────────────────────────

async function poll() {
  const reqHeaders = hdrs();

  try {
    const res = await fetch(
      `${settings.apiUrl}/api/notifications?limit=100`,
      { headers: reqHeaders },
    );
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const data = await res.json();
    const { notifications, unreadCount } = data;

    await chrome.storage.local.set({
      notifications: notifications || [],
      unreadCount: unreadCount || 0,
      lastPolled: Date.now(),
      lastError: null,
    });

    if (consecutiveErrors > 0) {
      consecutiveErrors = 0;
      await setupAlarm();
    }

    updateBadge(unreadCount);
    await maybeNotify(notifications || []);
  } catch (err) {
    console.error('[sentinel] poll error:', err.message);
    consecutiveErrors++;

    await chrome.storage.local.set({
      lastError: err.message,
      lastPolled: Date.now(),
    });

    if (consecutiveErrors > 1) {
      await setupAlarm(Math.min(consecutiveErrors, MAX_BACKOFF));
    }

    const existing = await chrome.storage.local.get('unreadCount');
    if (!existing.unreadCount) updateBadge(0, true);
  }

  // Heartbeat to API if Fusion Mode enabled
  if (settings.fusionMode) {
    sendHeartbeat().catch(err => console.warn('[sentinel] heartbeat failed:', err.message));
  }
}

// ── Fusion Mode: send heartbeat ────────────────────────────────────────────────

async function sendHeartbeat() {
  const reqHeaders = hdrs();
  try {
    const res = await fetch(`${settings.apiUrl}/api/extension/heartbeat`, {
      method: 'POST',
      headers: reqHeaders,
      body: JSON.stringify({ id: settings.extensionId }),
    });
    if (!res.ok) console.warn(`[sentinel] heartbeat failed: ${res.status}`);
  } catch (err) {
    console.warn('[sentinel] heartbeat error:', err.message);
  }
}

// ── Fusion Mode: verify connection ─────────────────────────────────────────────

async function verifyExtensionConnection() {
  const reqHeaders = hdrs();
  try {
    const res = await fetch(`${settings.apiUrl}/api/extension/health`, {
      headers: reqHeaders,
    });
    if (res.ok) {
      const health = await res.json();
      return { ok: true, health };
    }
  } catch (err) {
    console.error('[sentinel] connection verify failed:', err.message);
  }
  return { ok: false, health: null };
}

// ── Fusion Mode: repair listeners ──────────────────────────────────────────────

async function repairListeners() {
  const reqHeaders = hdrs();
  try {
    const res = await fetch(`${settings.apiUrl}/api/extension/listeners/repair`, {
      method: 'POST',
      headers: reqHeaders,
      body: JSON.stringify({ clientId: settings.extensionId }),
    });
    if (res.ok) {
      const result = await res.json();
      console.log('[sentinel] listeners repaired:', result);
      return true;
    }
  } catch (err) {
    console.error('[sentinel] repair failed:', err.message);
  }
  return false;
}

// ── Breaking-news notification ─────────────────────────────────────────────────

async function maybeNotify(notifications) {
  if (!chrome.notifications) return;

  const { lastNotifiedId } = await chrome.storage.local.get({ lastNotifiedId: null });
  const criticals = notifications.filter(n => n.urgency === 'critical' && n.status === 'unread');

  if (criticals.length === 0) return;

  const newest = criticals.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))[0];
  if (newest.id === lastNotifiedId) return;

  await chrome.storage.local.set({ lastNotifiedId: newest.id });

  chrome.notifications.create(`sentinel-${newest.id}`, {
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title: `🚨 Sentinel: ${newest.source}`,
    message: newest.title,
    priority: 2,
  });
}

// ── Alarm (background sync) ────────────────────────────────────────────────────

async function setupAlarm(backoffMultiplier = 1) {
  await chrome.alarms.clearAll();
  const baseSeconds = settings.pollIntervalSeconds || 30;
  const periodMinutes = Math.max((baseSeconds * backoffMultiplier) / 60, 0.5);
  chrome.alarms.create('poll', {
    delayInMinutes: 0,
    periodInMinutes: periodMinutes,
  });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'poll') poll();
});

// ── API Helpers ────────────────────────────────────────────────────────────────

function hdrs() {
  const h = { 'Content-Type': 'application/json' };
  if (settings.apiKey) h['X-Sentinel-Key'] = settings.apiKey;
  return h;
}

async function markRead(id, h) {
  const res = await fetch(`${settings.apiUrl}/api/notifications/${id}/read`, {
    method: 'POST', headers: h,
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const { notifications = [] } = await chrome.storage.local.get('notifications');
  const updated = notifications.map(n => n.id === id ? { ...n, status: 'read' } : n);
  const unreadCount = updated.filter(n => n.status === 'unread').length;
  await chrome.storage.local.set({ notifications: updated, unreadCount });
  updateBadge(unreadCount);
}

async function markAllRead(h) {
  const res = await fetch(`${settings.apiUrl}/api/notifications/read-all`, {
    method: 'POST', headers: h,
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const { notifications = [] } = await chrome.storage.local.get('notifications');
  const updated = notifications.map(n => ({ ...n, status: 'read' }));
  await chrome.storage.local.set({ notifications: updated, unreadCount: 0 });
  updateBadge(0);
}

async function dismiss(id, h) {
  const res = await fetch(`${settings.apiUrl}/api/notifications/${id}/dismiss`, {
    method: 'POST', headers: h,
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const { notifications = [] } = await chrome.storage.local.get('notifications');
  const updated = notifications.filter(n => n.id !== id);
  const unreadCount = updated.filter(n => n.status === 'unread').length;
  await chrome.storage.local.set({ notifications: updated, unreadCount });
  updateBadge(unreadCount);
}

// ── Action Parity: Hand Back to Agent ──────────────────────────────────────────

async function handBackToAgent(notificationId, h) {
  const res = await fetch(`${settings.apiUrl}/api/actions/hand-back`, {
    method: 'POST',
    headers: h,
    body: JSON.stringify({
      notificationId,
      taskTitle: 'Review Notification from Sentinel',
      taskDescription: `Notification ${notificationId} handed back from Sentinel for review`,
    }),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

// ── Action Parity: Restart Container ───────────────────────────────────────────

async function restartContainer(containerName, h) {
  const res = await fetch(`${settings.apiUrl}/api/actions/container/restart`, {
    method: 'POST',
    headers: h,
    body: JSON.stringify({ containerName }),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

// ── Action Parity: Snooze Notifications ────────────────────────────────────────

async function snoozeSource(source, minutes, h) {
  const res = await fetch(`${settings.apiUrl}/api/actions/snooze`, {
    method: 'POST',
    headers: h,
    body: JSON.stringify({ source, minutes }),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

// ── Message Bus ────────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  const handler = async () => {
    const h = hdrs();
    try {
      switch (msg.type) {
        case 'POLL_NOW':
          await poll();
          return { ok: true };
        case 'SETTINGS_UPDATED':
          consecutiveErrors = 0;
          await loadSettings();
          await setupAlarm();
          await poll();
          return { ok: true };
        case 'MARK_READ':
          await markRead(msg.id, h);
          return { ok: true };
        case 'MARK_ALL_READ':
          await markAllRead(h);
          await poll();
          return { ok: true };
        case 'DISMISS':
          await dismiss(msg.id, h);
          return { ok: true };
        case 'HAND_BACK':
          return await handBackToAgent(msg.id, h);
        case 'RESTART_CONTAINER':
          return await restartContainer(msg.containerName, h);
        case 'SNOOZE':
          return await snoozeSource(msg.source, msg.minutes || 30, h);
        case 'VERIFY_CONNECTION':
          return await verifyExtensionConnection();
        case 'REPAIR_LISTENERS':
          const repaired = await repairListeners();
          return { ok: repaired, repaired };
        case 'ENABLE_FUSION':
          await saveSettings({ fusionMode: true });
          return { ok: true, fusionMode: true };
        case 'DISABLE_FUSION':
          await saveSettings({ fusionMode: false });
          return { ok: true, fusionMode: false };
        default:
          return { ok: false, error: 'Unknown message type' };
      }
    } catch (err) {
      console.error(`[sentinel] message handler error (${msg.type}):`, err);
      return { ok: false, error: err.message };
    }
  };

  handler().then(reply).catch(() => reply({ ok: false }));
  return true; // async reply
});

// ── Lifecycle ──────────────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(async () => {
  // Auto-migrate from v1 settings if needed
  const migrated = await migrateSettingsIfNeeded();
  await loadSettings();

  if (migrated) {
    // Show migration summary
    console.log('[sentinel] v1→v2 migration complete');
    await chrome.storage.local.set({
      migrationSummary: {
        date: new Date().toISOString(),
        from: '1.2.0',
        to: '2.0.0',
        status: 'success',
      },
    });
  }

  await setupAlarm();
  poll();
});

chrome.runtime.onStartup.addListener(async () => {
  await loadSettings();
  await setupAlarm();
  poll();
});
