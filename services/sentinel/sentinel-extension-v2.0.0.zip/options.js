// AZ-Lab Sentinel v2.0.0 — Options Script with Fusion Mode & Export/Import

const DEFAULTS = {
  apiUrl: 'https://sentinel-api.az-lab.dev',
  apiKey: '',
  pollIntervalSeconds: 30,
  fusionMode: false,
};

async function load() {
  const s = await chrome.storage.sync.get(DEFAULTS);
  document.getElementById('apiUrl').value = s.apiUrl || '';
  document.getElementById('apiKey').value = s.apiKey || '';
  document.getElementById('pollInterval').value = s.pollIntervalSeconds || 30;
  document.getElementById('fusionMode').checked = s.fusionMode || false;

  // Show migration summary if available
  const { migrationSummary } = await chrome.storage.local.get('migrationSummary');
  if (migrationSummary) {
    showMigrationSummary(migrationSummary);
  }
}

function showMigrationSummary(summary) {
  const summaryEl = document.getElementById('migrationSummary');
  if (!summaryEl) return;

  summaryEl.innerHTML = `
    <div style="background: rgba(34, 197, 94, 0.1); border: 1px solid #22c55e; border-radius: 6px; padding: 12px; margin-bottom: 16px;">
      <p style="margin: 0; color: #22c55e; font-weight: bold;">✓ Successfully migrated from v${summary.from} to v${summary.to}</p>
      <p style="margin: 4px 0 0 0; color: #86efac; font-size: 12px;">${new Date(summary.date).toLocaleString()}</p>
    </div>
  `;
}

// ── Fusion Mode ────────────────────────────────────────────────────────────────

document.getElementById('fusionMode').addEventListener('change', async (e) => {
  const enabled = e.target.checked;

  if (enabled) {
    // Verify connection before enabling
    const result = await chrome.runtime.sendMessage(
      { type: 'VERIFY_CONNECTION' },
      (reply) => reply
    );

    if (result?.ok && result?.health?.connectedClients > 0) {
      await chrome.runtime.sendMessage({ type: 'ENABLE_FUSION' });
      showStatus('Fusion Mode enabled — extension is connected', 'success');
    } else {
      e.target.checked = false;
      showStatus('Cannot enable Fusion Mode: extension not connected to API', 'error');
    }
  } else {
    await chrome.runtime.sendMessage({ type: 'DISABLE_FUSION' });
    showStatus('Fusion Mode disabled', 'info');
  }
});

// ── Export Settings ────────────────────────────────────────────────────────────

document.getElementById('exportBtn')?.addEventListener('click', async () => {
  try {
    const { apiUrl, apiKey, pollIntervalSeconds, fusionMode } =
      await chrome.storage.sync.get(DEFAULTS);

    const { apiUrl: srvUrl } = await chrome.storage.sync.get({ apiUrl: DEFAULTS.apiUrl });
    const hdrs = { 'Content-Type': 'application/json' };
    if (apiKey) hdrs['X-Sentinel-Key'] = apiKey;

    const res = await fetch(`${apiUrl || srvUrl}/api/settings/export`, { headers: hdrs });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const exported = await res.json();
    const dataStr = JSON.stringify(exported, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `sentinel-settings-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);

    showStatus('Settings exported', 'success');
  } catch (err) {
    showStatus(`Export failed: ${err.message}`, 'error');
  }
});

// ── Import Settings ────────────────────────────────────────────────────────────

document.getElementById('importBtn')?.addEventListener('click', () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json';
  input.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      const text = await file.text();
      const imported = JSON.parse(text);

      if (!imported.settings || !imported.version) {
        throw new Error('Invalid settings file format');
      }

      // Apply imported settings
      const toSet = {
        apiUrl: imported.settings.apiUrl || DEFAULTS.apiUrl,
        apiKey: imported.settings.apiKey || '',
        pollIntervalSeconds: imported.settings.pollIntervalSeconds || 30,
        fusionMode: imported.settings.fusionMode || false,
      };

      await chrome.storage.sync.set(toSet);

      // Also save to server if API available
      const apiUrl = toSet.apiUrl;
      const hdrs = { 'Content-Type': 'application/json' };
      if (toSet.apiKey) hdrs['X-Sentinel-Key'] = toSet.apiKey;

      try {
        await fetch(`${apiUrl}/api/settings/import`, {
          method: 'POST',
          headers: hdrs,
          body: JSON.stringify({ settings: imported.settings }),
        });
      } catch { /* silent fail */ }

      await load();
      showStatus('Settings imported successfully', 'success');
    } catch (err) {
      showStatus(`Import failed: ${err.message}`, 'error');
    }
  });
  input.click();
});

// ── Save Settings ──────────────────────────────────────────────────────────────

document.getElementById('saveBtn').addEventListener('click', async () => {
  const settings = {
    apiUrl: document.getElementById('apiUrl').value.trim().replace(/\/$/, ''),
    apiKey: document.getElementById('apiKey').value.trim(),
    pollIntervalSeconds: Math.max(10, parseInt(document.getElementById('pollInterval').value, 10) || 30),
    fusionMode: document.getElementById('fusionMode').checked,
  };

  await chrome.storage.sync.set(settings);
  chrome.runtime.sendMessage({ type: 'SETTINGS_UPDATED' });

  showStatus('Settings saved', 'success');
});

// ── Status display ─────────────────────────────────────────────────────────────

function showStatus(message, type = 'info') {
  let msg = document.getElementById('statusMsg');
  if (!msg) {
    msg = document.createElement('div');
    msg.id = 'statusMsg';
    msg.style.cssText = `
      position: fixed; top: 16px; right: 16px;
      padding: 12px 16px; border-radius: 6px;
      font-size: 13px; z-index: 9999;
      opacity: 0; transition: opacity 0.3s;
    `;
    document.body.appendChild(msg);
  }

  const colors = {
    success: { bg: 'rgba(34, 197, 94, 0.2)', color: '#22c55e', border: '1px solid #22c55e' },
    error: { bg: 'rgba(239, 68, 68, 0.2)', color: '#ef4444', border: '1px solid #ef4444' },
    info: { bg: 'rgba(59, 130, 246, 0.2)', color: '#3b82f6', border: '1px solid #3b82f6' },
  };

  const style = colors[type] || colors.info;
  msg.style.background = style.bg;
  msg.style.color = style.color;
  msg.style.border = style.border;
  msg.textContent = message;
  msg.style.opacity = '1';

  setTimeout(() => {
    msg.style.opacity = '0';
  }, 2500);
}

load();
