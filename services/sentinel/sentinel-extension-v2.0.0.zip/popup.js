// AZ-Lab Sentinel v2.0.0 — Popup Script with Action Parity

const SOURCE_LABELS = {
  task_queue: 'Tasks',
  home_assistant: 'HA',
  grafana: 'Grafana',
  services: 'Services',
  agent_health: 'Agents',
  discord: 'Discord',
};

let activeSource = 'all';
let activeTab = 'live';
let historyLoaded = false;
let historyOffset = 0;
const HISTORY_PAGE = 50;

// ── DOM refs ───────────────────────────────────────────────────────────────────
const els = {
  badgeSummary: document.getElementById('badgeSummary'),
  refreshBtn: document.getElementById('refreshBtn'),
  filterBar: document.getElementById('filterBar'),
  notifList: document.getElementById('notificationList'),
  historyList: document.getElementById('historyList'),
  lastUpdated: document.getElementById('lastUpdated'),
  markAllReadBtn: document.getElementById('markAllReadBtn'),
  loadMoreBtn: document.getElementById('loadMoreBtn'),
  errorBanner: document.getElementById('errorBanner'),
  errorText: document.getElementById('errorText'),
};

// ── Init ───────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await renderLive();
  setupTabs();
  setupFilters();
  setupActions();
  listenStorage();
});

// ── Storage listener ───────────────────────────────────────────────────────────
function listenStorage() {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && activeTab === 'live') renderLive();
  });
}

// ── Render live tab ────────────────────────────────────────────────────────────
async function renderLive() {
  const { notifications = [], unreadCount = 0, lastPolled, lastError } =
    await chrome.storage.local.get(['notifications', 'unreadCount', 'lastPolled', 'lastError']);

  if (unreadCount > 0) {
    els.badgeSummary.textContent = `${unreadCount} unread`;
    els.badgeSummary.className = 'badge-summary has-unread';
  } else {
    els.badgeSummary.textContent = 'no unread';
    els.badgeSummary.className = 'badge-summary';
  }

  if (lastPolled) {
    els.lastUpdated.textContent = `Updated ${timeAgo(lastPolled)}`;
  }

  if (lastError) {
    showError(lastError);
  } else {
    hideError();
  }

  const filtered = filterNotifications(notifications, activeSource);
  renderList(els.notifList, filtered, false);
}

// ── Render history tab ─────────────────────────────────────────────────────────
async function renderHistory(append = false) {
  if (!append) {
    historyOffset = 0;
    els.historyList.innerHTML = '<div class="empty-state">Loading history...</div>';
  }

  const { apiUrl = 'https://sentinel-api.az-lab.dev', apiKey = '' } =
    await chrome.storage.sync.get(['apiUrl', 'apiKey']);

  const headers = {};
  if (apiKey) headers['X-Sentinel-Key'] = apiKey;

  const sourceParam = activeSource !== 'all' ? `&source=${activeSource}` : '';
  const url = `${apiUrl}/api/notifications/history?limit=${HISTORY_PAGE}&offset=${historyOffset}${sourceParam}`;

  try {
    const res = await fetch(url, { headers });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const { notifications = [], total = 0 } = data;

    historyOffset += notifications.length;

    if (!append) {
      renderList(els.historyList, notifications, true);
    } else {
      appendList(els.historyList, notifications, true);
    }

    els.loadMoreBtn.style.display = historyOffset < total ? 'block' : 'none';

  } catch (err) {
    if (!append) {
      els.historyList.innerHTML = `<div class="empty-state">Failed to load history: ${err.message}</div>`;
    }
    showError(err.message);
  }
}

// ── Render helpers ─────────────────────────────────────────────────────────────
function renderList(container, notifications, isHistory) {
  if (!notifications.length) {
    container.innerHTML = '<div class="empty-state">No notifications</div>';
    return;
  }
  container.innerHTML = '';
  for (const n of notifications) {
    container.appendChild(buildCard(n, isHistory));
  }
}

function appendList(container, notifications, isHistory) {
  for (const n of notifications) {
    container.appendChild(buildCard(n, isHistory));
  }
}

// ── Build notification card with action parity ─────────────────────────────────
function buildCard(n, isHistory) {
  const div = document.createElement('div');
  div.className = `notif-card ${n.status}`;
  div.dataset.id = n.id;

  const time = n.timestamp ? timeAgo(new Date(n.timestamp).getTime()) : '—';
  const sourceLabel = SOURCE_LABELS[n.source] || n.source;

  // Actions for live view
  let actionsHtml = '';
  if (!isHistory) {
    const actions = [];

    if (n.status === 'unread') {
      actions.push(`<button class="action-btn read-btn" title="Mark read">✓</button>`);
    }

    actions.push(`<button class="action-btn dismiss-btn" title="Dismiss">✕</button>`);

    // Hand back to agent action
    actions.push(`<button class="action-btn hand-back-btn" title="Hand back to agent">⤴</button>`);

    // Snooze action
    actions.push(`<button class="action-btn snooze-btn" title="Snooze this source">⏱</button>`);

    actionsHtml = `<div class="notif-actions">${actions.join('')}</div>`;
  }

  div.innerHTML = `
    <div class="notif-stripe ${n.urgency || n.severity}"></div>
    <div class="notif-body">
      <div class="notif-header">
        <div class="notif-sev ${n.urgency || n.severity}"></div>
        <div class="notif-title">${esc(n.title)}</div>
        ${actionsHtml}
      </div>
      ${n.body ? `<div class="notif-text">${esc(n.body)}</div>` : ''}
      <div class="notif-footer">
        <div class="notif-meta">
          <span class="source-tag ${n.source}">${sourceLabel}</span>
          <span class="notif-time">${time}</span>
        </div>
      </div>
    </div>
  `;

  if (!isHistory) {
    const readBtn = div.querySelector('.read-btn');
    const dismissBtn = div.querySelector('.dismiss-btn');
    const handBackBtn = div.querySelector('.hand-back-btn');
    const snoozeBtn = div.querySelector('.snooze-btn');

    if (readBtn) {
      readBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.runtime.sendMessage({ type: 'MARK_READ', id: n.id }, () => {
          div.className = 'notif-card read';
          readBtn.remove();
        });
      });
    }

    if (dismissBtn) {
      dismissBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.runtime.sendMessage({ type: 'DISMISS', id: n.id }, () => {
          div.remove();
        });
      });
    }

    if (handBackBtn) {
      handBackBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.runtime.sendMessage({ type: 'HAND_BACK', id: n.id }, (result) => {
          if (result?.ok) {
            div.innerHTML = '<div class="action-success">✓ Handed back to agent</div>';
          }
        });
      });
    }

    if (snoozeBtn) {
      snoozeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.runtime.sendMessage(
          { type: 'SNOOZE', source: n.source, minutes: 30 },
          (result) => {
            if (result?.ok) {
              snoozeBtn.textContent = '✓';
              snoozeBtn.disabled = true;
            }
          }
        );
      });
    }
  }

  return div;
}

// ── Filter helpers ─────────────────────────────────────────────────────────────
function filterNotifications(notifications, source) {
  if (source === 'all') return notifications;
  return notifications.filter(n => n.source === source);
}

// ── Tab setup ──────────────────────────────────────────────────────────────────
function setupTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', async () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      activeTab = tab.dataset.tab;

      document.querySelectorAll('.tab-content').forEach(tc => tc.classList.remove('active'));
      const target = document.getElementById(`${activeTab}Tab`);
      if (target) target.classList.add('active');

      if (activeTab === 'history' && !historyLoaded) {
        historyLoaded = true;
        await renderHistory();
      }
    });
  });
}

// ── Filter pill setup ──────────────────────────────────────────────────────────
function setupFilters() {
  els.filterBar.querySelectorAll('.pill').forEach(pill => {
    pill.addEventListener('click', async () => {
      els.filterBar.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      activeSource = pill.dataset.source;

      if (activeTab === 'live') {
        await renderLive();
      } else {
        historyLoaded = false;
        await renderHistory();
        historyLoaded = true;
      }
    });
  });
}

// ── Actions ────────────────────────────────────────────────────────────────────
function setupActions() {
  els.refreshBtn.addEventListener('click', async () => {
    els.refreshBtn.classList.add('spinning');
    chrome.runtime.sendMessage({ type: 'POLL_NOW' }, async () => {
      await renderLive();
      els.refreshBtn.classList.remove('spinning');
    });
  });

  els.markAllReadBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'MARK_ALL_READ' }, () => renderLive());
  });

  els.loadMoreBtn.addEventListener('click', async () => {
    await renderHistory(true);
  });
}

// ── Utility ────────────────────────────────────────────────────────────────────
function timeAgo(ts) {
  const diff = Date.now() - (typeof ts === 'number' ? ts : new Date(ts).getTime());
  if (diff < 60_000) return 'just now';
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`;
  return `${Math.floor(diff / 86_400_000)}d ago`;
}

function esc(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function showError(msg) {
  els.errorText.textContent = msg;
  els.errorBanner.style.display = 'block';
}

function hideError() {
  els.errorBanner.style.display = 'none';
}
